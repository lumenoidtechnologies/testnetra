const { ipcRenderer } = require('electron');

// Retrieve the HTML elements
const nameInput = document.getElementById('nameInput');
const emailInput = document.getElementById('emailInput');
const insertUserBtn = document.getElementById('insertUserBtn');

// Handle the button click event
insertUserBtn.addEventListener('click', () => {
  const name = nameInput.value;
  const email = emailInput.value;
  // Send IPC message to the main process with the name and email
  ipcRenderer.send('dataInsertion', { name, email });
});

// Receive the users data from the main process and update the UI
ipcRenderer.on('usersData', (event, users) => {
  const usersList = document.getElementById('usersList');
  usersList.innerHTML = '';
  users.forEach((user) => {
    const listItem = document.createElement('li');
    listItem.textContent = `${user.name} - ${user.email}`;
    usersList.appendChild(listItem);
  });
});
