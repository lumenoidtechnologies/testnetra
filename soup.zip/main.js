const { app, BrowserWindow, ipcMain } = require('electron');
const path = require('path');
const sqlite3 = require('sqlite3').verbose();

const isDev = process.env.NODE_ENV !== 'production';

let mainWindow;

// Create a new SQLite database connection
const db = new sqlite3.Database('data.db');

// Create the table if it doesn't exist
db.run(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT
)`);

// Function to insert a new user into the database
function insertUser(name, email) {
  db.run('INSERT INTO users (name, email) VALUES (?, ?)', [name, email], (err) => {
    if (err) {
      console.error(err);
      return;
    }
    console.log('User inserted successfully.');
  });
}

// Function to fetch all users from the database
function fetchUsers() {
  db.all('SELECT * FROM users', [], (err, rows) => {
    if (err) {
      console.error(err);
      return;
    }
    mainWindow.webContents.send('usersData', rows);
  });
}

// Create the main window
function createWindow() {
  mainWindow = new BrowserWindow({
    webPreferences: {
      nodeIntegration: true,
      contextIsolation: false,
      enableRemoteModule: true,
    },
  });
  mainWindow.loadFile(path.join(__dirname, 'index.html'));

  // Open the developer tools in dev mode
  if (isDev) {
    mainWindow.webContents.openDevTools();
  }

  // Example usage: Insert a user
  insertUser('sahil', 'sahil@example.com');

  // Example usage: Fetch all users
  mainWindow.webContents.once('did-finish-load', () => {
    fetchUsers();
  });
}

// Event handler when Electron has finished initialization
app.whenReady().then(createWindow);

// Handle IPC communication to insert data into the database
ipcMain.on('dataInsertion', (event, data) => {
  const { name, email } = data;
  insertUser(name, email);
});
